
To use the LM741

(1) unzip everything
(2) place LM741.MOD in this folder

    C:\Program Files\LTC\LTspiceIV\lib\sub
(3) place LM741.asy in any convienent LTSpice folder (I have "my device" folder) to keep them seperate.

The LM741.MOD file was created by the LM741 device manufacturer - so it should be safe and accurate.
The LM741.asy file was created / modified as per "how to create LM741.txt".

Good Luck and have fun.

====

P.S.  I created this file because I was just trying to get used to LTSpice.  I needed to create "hello world" type of simple circuits. So there's absolutely no guarantees to the accuracy or quality of this device.  But I've found it to be useful and accurate in my own personal use (so far).